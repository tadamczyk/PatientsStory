﻿namespace PatientsStory.DataAccess.Interfaces
{
    public interface ILocalFileHelper
    {
        string GetLocalFilePath(string filename);
    }
}